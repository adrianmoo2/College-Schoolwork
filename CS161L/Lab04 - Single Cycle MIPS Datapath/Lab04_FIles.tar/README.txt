Name: Adrian Tran
SID: 861233198

Completed functionalities: I believe everything for the MIPS datapath and processor
are correct. However, I keep getting errors when I'm trying to load in the .coe file.

Incomplete functionalities: (I believe) None.