Name: Adrian Tran

Correct functionalities: I believe all the functionalities are correct

Incorrect functionalities: N/A