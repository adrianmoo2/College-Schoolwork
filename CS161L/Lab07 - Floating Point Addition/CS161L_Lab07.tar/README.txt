Name: Adrian Tran
SID: 861233198

Complete functionalities: All

Incomplete functionalities: N/A