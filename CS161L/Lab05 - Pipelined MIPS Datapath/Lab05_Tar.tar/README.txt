Name: Adrian Tran (atran059)
SID: 861233198

Complete Functionalities: (Nearly) all

Incomplete functionalities: Write_reg_data does not pipeline correctly. Minor bug. Working on it, and should be finished shortly.