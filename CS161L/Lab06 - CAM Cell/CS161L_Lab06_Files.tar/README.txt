Name: Adrian Tran
SID: 861233198

Incomplete: Getting high impedance for decoded word

Complete: Everything else is good, I think.