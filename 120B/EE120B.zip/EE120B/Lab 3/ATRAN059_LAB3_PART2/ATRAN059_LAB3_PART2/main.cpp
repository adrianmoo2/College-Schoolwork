/*
 * ATRAN059_LAB3_PART2.cpp
 *
 * Created: 1/15/2018 2:35:08 PM
 * Author : Adrian
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

