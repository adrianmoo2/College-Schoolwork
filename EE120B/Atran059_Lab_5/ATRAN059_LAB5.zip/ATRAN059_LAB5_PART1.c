/*
 * ATRAN059_LAB5_PART1.c
 *
 * Created: 2/1/2018 3:57:38 PM
 *  Author: student
 */ 


#include <avr/io.h>
volatile unsigned char TimerFlag = 0;
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks	
enum States {Start, Init, Wait, SwitchOne, SwitchTwo, SwitchThree} state;
	
unsigned char SetBit(unsigned char x, unsigned char k, unsigned char b) {
	return (b ? x | (0x01 << k) : x & ~(0x01 << k));
}
unsigned char GetBit(unsigned char x, unsigned char k) {
	return ((x & (0x01 << k)) != 0);
}

void TimerISR() {
	TimerFlag = 1;
}

void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

	
void Tick() {
		switch (state) {
		case Start:
			state = Init;
			break;
		case Init:
			state = Wait;
			break;
		case Wait:
			state = GetBit(PORTB, 0) ? SwitchOne : state;
			state = GetBit(PORTB, 1) ? SwitchTwo: state;
			state = GetBit(PORTB, 2) ? SwitchThree : state; 
			break;
		case SwitchOne:
			break;
		case SwitchTwo:
			break;
		case SwitchThree:
			break;
		default:
			break;
	}
	
	switch (state) {
		case Start:
			break;
		case Init:
			PORTB = 0x01;
			break;
		case Wait:
			break;
		case SwitchOne:
			PORTB = SetBit(PORTB, 0, 0);
			PORTB = SetBit(PORTB, 1, 1);
			break;
		case SwitchTwo:
			PORTB = SetBit(PORTB, 1, 0);
			PORTB = SetBit(PORTB, 2, 1);
			break;
		case SwitchThree:
			PORTB = SetBit(PORTB, 2, 0);
			PORTB = SetBit(PORTB, 0, 1);
			break;
		default:
			break;
	}
}


int main(void)
{
	DDRB = 0xFF; PORTB = 0x00;
	state = Start;
	TimerSet(500);
	TimerOn();
	
    while(1)
    {
        Tick();
		while (!TimerFlag) {}
		TimerFlag = 0;
    }
}